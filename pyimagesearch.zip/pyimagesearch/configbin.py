# import the necessary packages
import os

# initialize the list of class label names
CLASSES = ["abnormal", "normal"]

# define the minimum learning rate, maximum learning rate, batch size,
# step size, CLR method, and number of epochs
MIN_LR = 1e-12
MAX_LR = 1e-4
BATCH_SIZE = 16
STEP_SIZE = 8
CLR_METHOD = "triangular"
NUM_EPOCHS = 20

# define the path to the output learning rate finder plot, training
# history plot and cyclical learning rate plot
LRFIND_PLOT_PATH = os.path.sep.join(["output", "bin_lrfind_plot.png"])
TRAINING_PLOT_PATH = os.path.sep.join(["output", "bin_training_plot.png"])
CLR_PLOT_PATH = os.path.sep.join(["output", "bin_clr_plot.png"])
